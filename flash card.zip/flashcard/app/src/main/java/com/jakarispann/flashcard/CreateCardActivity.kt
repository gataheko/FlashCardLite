package com.jakarispann.flashcard

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class CreateCardActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_card)
    }
}